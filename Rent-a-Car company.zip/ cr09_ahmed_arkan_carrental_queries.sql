

////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////                                    ////////////////
////////////////    some different SQL queries     /////////////////
////////////////         for my database          //////////////////
////////////////                                 ///////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////




1. SELECT COUNT(*) FROM customer; 												(10)

2. SELECT COUNT(*) FROM cars; 													(10)

3. SELECT COUNT(*) FROM cars WHERE car_type LIKE'bmw%'; 						(4)

3. SELECT COUNT(*) FROM customer WHERE first_name LIKE'a%';						(2)

4.SELECT COUNT(*) FROM resevation WHERE pickup_date LIKE'2017-12%;				(3)

5.SELECT COUNT(*) FROM location WHERE address LIKE'landstrasse%';				(5)

6.SELECT COUNT(*) FROM invoice WHERE cost > 20;									(4)

7.SELECT COUNT(*) FROM rent WHERE car_type LIKE'mercedes%';						(3)

8.SELECT COUNT(*) FROM `return_location` WHERE fk_additional_charges_id =1;     (4)
hint: 1 = good (the car return whith no damiged).

9.SELECT COUNT(*) FROM `return_location` WHERE fk_additional_charges_id =6;		(3)
hint: 6 = not full tank (the car return whith unfull tank).

10.SELECT COUNT(*) FROM resevation WHERE fk_invoice_id =1 ;						(3)
hint: 1 = 1hour & 20 (the car rent for just 1 hour and cost 20€ ).

11.SELECT COUNT(*) FROM resevation WHERE fk_invoice_id =5;						(1)
hint: 5 = 24hours & 230 (the car rent for 24 hours and cost 230€).