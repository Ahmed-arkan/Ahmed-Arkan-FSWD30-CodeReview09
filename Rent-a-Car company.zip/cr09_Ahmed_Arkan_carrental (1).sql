-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 03, 2018 at 02:09 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.1.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cr09_Ahmed_Arkan_carrental`
--

-- --------------------------------------------------------

--
-- Table structure for table `additional_charges`
--

CREATE TABLE `additional_charges` (
  `additional_charges_id` int(11) NOT NULL,
  `if_car` varchar(255) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `additional_charges`
--

INSERT INTO `additional_charges` (`additional_charges_id`, `if_car`, `cost`) VALUES
(1, 'good', 0),
(2, 'the car have damiged', 150),
(3, 'have Traffic violation', 40),
(4, 'lost the car key', 70),
(6, 'the tank not full', 30);

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `car_id` int(11) NOT NULL,
  `car_type` varchar(55) DEFAULT NULL,
  `mudel` year(4) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`car_id`, `car_type`, `mudel`, `location`) VALUES
(1, 'bmw 720', 2014, 'landstrasse 22/7'),
(2, 'bmw m4', 2010, 'landstrasse 22/7'),
(3, 'opel dd', 2013, 'landstrasse 22/7'),
(4, 'audi a4', 2016, 'grinzing allee strasse 33'),
(5, 'bmw x5', 2015, 'grinzing allee strasse 33'),
(6, 'bmw x6', 2013, 'grinzing allee strasse 33'),
(7, 'mercedes_benz mls', 2015, 'landstrasse 22/7'),
(8, 'audi q5', 2014, 'grinzing allee strasse 33'),
(9, 'mercedes benz smart ', 2014, 'landstrase 22/7'),
(10, 'kia sportig', 2016, 'grinzing allee strasse 33');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `first_name` varchar(55) DEFAULT NULL,
  `last_name` varchar(55) DEFAULT NULL,
  `phone_number` int(11) DEFAULT NULL,
  `license_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `first_name`, `last_name`, `phone_number`, `license_number`) VALUES
(1, 'lena', 'smith', 66023124, 3523536),
(2, 'eren', 'freemann', 874534523, 3232424),
(3, 'peter', 'kleven', 75982762, 32523532),
(4, 'demarcus', 'howrd', 239523862, 2335235),
(5, 'mark', 'oliver', 23523623, 79679654),
(6, 'anna', 'larson', 325236637, 2362333),
(7, 'tara', 'samer', 39759893, 7587899),
(8, 'ramy', 'albader', 79869055, 897977),
(9, 'ali', 'ramse', 997463243, 6248946),
(10, 'zahra', 'gerrard', 23626236, 3263777);

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invoice_id` int(11) NOT NULL,
  `pack_types` varchar(55) NOT NULL,
  `cost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invoice_id`, `pack_types`, `cost`) VALUES
(1, '1hour', 20),
(2, '2houer', 40),
(3, '6hour', 100),
(4, '12hour', 150),
(5, '24hour', 230);

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `location_id` int(11) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `fk_start_location_id` int(11) DEFAULT NULL,
  `fk_return_location_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`location_id`, `address`, `fk_start_location_id`, `fk_return_location_id`) VALUES
(1, 'landstrasse 22/7', 1, 5),
(2, 'landstrasse 22/7', 4, 9),
(3, 'landstrasse 22/7', 2, 9),
(4, 'grinzing allee strasse 33', 2, 7),
(5, 'grinzing allee strasse 33', 8, 9),
(6, 'grinzing allee strasse 33', 1, 2),
(7, 'landstrasse 22', 8, 9),
(8, 'grinzing allee strasse 33', 9, 4),
(9, 'landstrasse 22', 3, 9),
(10, 'grinzing allee strasse 33', 2, 10);

-- --------------------------------------------------------

--
-- Table structure for table `rent`
--

CREATE TABLE `rent` (
  `rent_id` int(11) NOT NULL,
  `car_type` varchar(55) DEFAULT NULL,
  `fk_location_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rent`
--

INSERT INTO `rent` (`rent_id`, `car_type`, `fk_location_id`) VALUES
(1, 'bmw m4', 2),
(2, 'mercedes benz smart ', 9),
(3, 'audi a4', 4),
(4, 'bmw x5', 1),
(5, 'mercedes_benz mls', 2),
(6, 'opel dd', 6),
(7, 'audi q5', 9),
(8, 'kia sportig', 8),
(9, 'bmw x6', 1),
(10, 'mercedes benz mls', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `resevation`
--

CREATE TABLE `resevation` (
  `resevation_id` int(11) NOT NULL,
  `fk_customer_id` int(11) DEFAULT NULL,
  `fk_location_id` int(11) DEFAULT NULL,
  `fk_car_id` int(11) DEFAULT NULL,
  `fk_invoice_id` int(11) DEFAULT NULL,
  `fk_rent_id` int(11) NOT NULL,
  `pickup_date` date NOT NULL,
  `pickup_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `resevation`
--

INSERT INTO `resevation` (`resevation_id`, `fk_customer_id`, `fk_location_id`, `fk_car_id`, `fk_invoice_id`, `fk_rent_id`, `pickup_date`, `pickup_time`) VALUES
(1, 9, 1, 3, 2, 6, '2017-12-20', '11:42:15'),
(2, 6, 9, 7, 4, 5, '2017-12-19', '12:18:35'),
(3, 4, 8, 9, 2, 10, '2017-01-22', '13:14:35'),
(4, 2, 1, 10, 1, 8, '2017-01-07', '18:18:35'),
(5, 1, 5, 6, 3, 9, '2017-02-04', '02:01:35'),
(6, 5, 8, 5, 5, 4, '2017-02-05', '19:42:15'),
(7, 3, 2, 2, 1, 1, '2017-01-22', '12:42:15'),
(8, 8, 6, 1, 1, 1, '2017-12-13', '11:43:15'),
(9, 7, 1, 8, 3, 7, '2017-02-06', '13:42:15'),
(10, 10, 5, 4, 2, 3, '2017-02-01', '11:42:15');

-- --------------------------------------------------------

--
-- Table structure for table `return_location`
--

CREATE TABLE `return_location` (
  `return_location_id` int(11) NOT NULL,
  `address` varchar(55) DEFAULT NULL,
  `fk_additional_charges_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `return_location`
--

INSERT INTO `return_location` (`return_location_id`, `address`, `fk_additional_charges_id`) VALUES
(1, '\'grinzing allee strasse 33/7', 1),
(2, '\'grinzing allee strasse 33/7', 6),
(3, 'landstrasse 22', 4),
(4, 'landstrasse 22/7', 1),
(5, '\'grinzing allee strasse 33/7', 6),
(6, '\'grinzing allee strasse 33/7', 1),
(7, 'landstrasse 22/7', 1),
(8, '\'grinzing allee strasse 33/7', 2),
(9, 'landstrasse 22/7', 4),
(10, 'landstrasse 22/7', 6);

-- --------------------------------------------------------

--
-- Table structure for table `start_location`
--

CREATE TABLE `start_location` (
  `start_location_id` int(11) NOT NULL,
  `address` varchar(55) DEFAULT NULL,
  `pickup_date` date DEFAULT NULL,
  `pickup_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `start_location`
--

INSERT INTO `start_location` (`start_location_id`, `address`, `pickup_date`, `pickup_time`) VALUES
(1, 'landstrasse 22/7', '2017-12-20', '11:42:15'),
(2, 'grinzing allee strasse 33', '2017-12-19', '12:18:35'),
(3, 'landstrasse 22/7', '2017-01-22', '13:14:35'),
(4, 'grinzing allee strasse 33', '2017-01-07', '18:18:35'),
(5, 'landstrasse 22/7', '2017-02-04', '02:01:35'),
(6, 'landstrasse 22/7', '2017-02-05', '19:42:15'),
(7, 'grinzing allee strasse 33', '2017-01-22', '12:42:15'),
(8, 'grinzing allee strasse 33', '2017-12-13', '11:43:15'),
(9, 'landstrasse 22/7', '2017-02-06', '13:42:15'),
(19, 'grinzing allee strasse 33', '2017-02-01', '11:42:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `additional_charges`
--
ALTER TABLE `additional_charges`
  ADD PRIMARY KEY (`additional_charges_id`);

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`car_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invoice_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `location_ibfk_1` (`fk_start_location_id`),
  ADD KEY `location_ibfk_2` (`fk_return_location_id`);

--
-- Indexes for table `rent`
--
ALTER TABLE `rent`
  ADD PRIMARY KEY (`rent_id`),
  ADD KEY `rent_ibfk_1` (`fk_location_id`);

--
-- Indexes for table `resevation`
--
ALTER TABLE `resevation`
  ADD PRIMARY KEY (`resevation_id`),
  ADD KEY `fk_customer_id` (`fk_customer_id`),
  ADD KEY `resevation_ibfk_3` (`fk_location_id`),
  ADD KEY `resevation_ibfk_4` (`fk_car_id`),
  ADD KEY `resevation_ibfk_5` (`fk_invoice_id`),
  ADD KEY `resevation_ibfk_6` (`fk_rent_id`);

--
-- Indexes for table `return_location`
--
ALTER TABLE `return_location`
  ADD PRIMARY KEY (`return_location_id`),
  ADD KEY `return_location_ibfk_1` (`fk_additional_charges_id`);

--
-- Indexes for table `start_location`
--
ALTER TABLE `start_location`
  ADD PRIMARY KEY (`start_location_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `location`
--
ALTER TABLE `location`
  ADD CONSTRAINT `location_ibfk_1` FOREIGN KEY (`fk_start_location_id`) REFERENCES `start_location` (`start_location_id`),
  ADD CONSTRAINT `location_ibfk_2` FOREIGN KEY (`fk_return_location_id`) REFERENCES `return_location` (`return_location_id`);

--
-- Constraints for table `rent`
--
ALTER TABLE `rent`
  ADD CONSTRAINT `rent_ibfk_1` FOREIGN KEY (`fk_location_id`) REFERENCES `location` (`location_id`);

--
-- Constraints for table `resevation`
--
ALTER TABLE `resevation`
  ADD CONSTRAINT `resevation_ibfk_2` FOREIGN KEY (`fk_customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `resevation_ibfk_3` FOREIGN KEY (`fk_location_id`) REFERENCES `location` (`location_id`),
  ADD CONSTRAINT `resevation_ibfk_4` FOREIGN KEY (`fk_car_id`) REFERENCES `cars` (`car_id`),
  ADD CONSTRAINT `resevation_ibfk_5` FOREIGN KEY (`fk_invoice_id`) REFERENCES `invoice` (`invoice_id`),
  ADD CONSTRAINT `resevation_ibfk_6` FOREIGN KEY (`fk_rent_id`) REFERENCES `rent` (`rent_id`);

--
-- Constraints for table `return_location`
--
ALTER TABLE `return_location`
  ADD CONSTRAINT `return_location_ibfk_1` FOREIGN KEY (`fk_additional_charges_id`) REFERENCES `additional_charges` (`additional_charges_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
